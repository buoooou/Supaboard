const n=`---
title: "2026最新Quantumult X使用教程：iOS小白也能轻松上手的圈叉配置指南"
description: "正在寻找Quantumult X使用教程？本文为您详细介绍iOS最强网络工具圈叉(Quantumult X)的下载安装、节点订阅添加及分流模式设置，助您轻松掌握这一全能神器。"
date: 2026-05-03
image: /blog/quantumult_x_tutorial_cover.png
authors:
  - buoooou
---

在 iOS 平台上，提到科学上网的神器，除了大众熟知的 [Shadowrocket (小火箭)](/blog/shadowrocket-shared-apple-id-guide) 之外，**Quantumult X** (俗称“圈叉”) 无疑是进阶玩家和小白用户都值得拥有的一款全能网络工具。它不仅支持 MitM、HTTP Debug、JS 脚本，还拥有极高的性能与易用性。本文将为您带来一份详尽的 **Quantumult X 使用教程**，助您快速上手。

## Quantumult X 的下载与安装

Quantumult X 是一款付费软件，由于政策原因，在中国大陆地区的 App Store 是无法搜索到的。

- **下载建议**：您需要切换 App Store 地区至非中国大陆地区（如美区、港区或日区），或者新注册一个海外 Apple ID。
- **获取 ID**：如果您还没有海外 ID，可以参考我们关于 [小火箭共享账号](/blog/shadowrocket-shared-apple-id-guide) 的文章，了解如何获取免费 ID 进行下载。

---

## Quantumult X 使用教程：快速添加订阅

下载好软件后，第一步就是将您的机场节点导入。

### 1. 复制订阅地址
首先，前往您的用户中心复制 SS、SSR、V2Ray 或 Trojan 的订阅地址。

### 2. 在 QX 中引用订阅
打开 Quantumult X，点击右下角的 **圆形按钮** (功能菜单)。
在弹出的菜单中，选择 **“节点”** 一栏中的 **“引用 (订阅)”** 选项。

### 3. 填入资源链接
将刚才复制的订阅地址粘贴进去，点击右上角的 **“确定”**。此时，Quantumult X 将开始自动拉取并更新节点列表。

---

## 节点选择与连接测试

回到软件首页，您现在应该能看到整齐的节点列表了。

- **延迟检测**：在主界面向下拉动，即可触发全局节点的延迟检测，方便您筛选出最快的线路。
- **开启服务**：打开右上角的开关。首次连接时，iOS 会弹出“添加 VPN 配置”的提示，点击 **“允许”** 并输入密码即可连接成功。

如果您还不确定什么样的节点才算“优质”，建议阅读 [如何选择稳定机场](/blog/how-to-choose-stable-airport-guide) 以提升您的上网体验。

---

## 模式切换：全局 vs 分流

为了兼顾国内网站的访问速度，我们需要合理配置运行模式。

- **全局代理**：所有流量都走代理，适合排查网络问题。
- **分流模式 (推荐)**：长按右下角的圆形按钮，在弹出的黄、白、蓝三个按钮中选择 **白色**，即切换至分流模式。此时系统会根据预设规则，自动决定哪些网站走代理，哪些网站直连（如百度、淘宝等）。

如果您之前习惯使用 [Clash 使用教程](/blog/clash-usage-tutorial-and-config-guide) 中的规则分流，您会发现 QX 的分流逻辑同样非常强大。

---

## 总结与推荐

掌握了这份 **Quantumult X 使用教程** 后，您已经能够驾驭这款 iOS 端的顶级神器。为了发挥圈叉的最大威力，建议搭配具备 **IPLC/IEPL 专线** 的高品质机场服务。

相比于传统的 [机场与VPN的区别](/blog/what-is-airport-proxy-vs-vpn)，Supaboard 为 Quantumult X 用户提供了专属的优化配置，确保无论是在刷推特、看奈飞还是使用 AI 工具时，都能获得丝滑的连接体验。

[立即注册并订阅 Supaboard](https://cdn.supaboard.cc/#/register?code=xT9EdJGD)

想要探索更多关于 QX 的 JS 脚本和重写功能？欢迎查阅我们的 [使用教程](/docs) 或加入社群讨论。
`;export{n as default};
